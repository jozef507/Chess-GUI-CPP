---------------------------------------------------------------------------------------------

ICP-2019 Projekt: �achy:

Aplik�cia/hra �achy ovl�d�ne vlastn�mi tahmi u��vate�a alebo not�ciou, na��tanou zo s�boru.

Autori:  Jan Hol�sek
	 Jozef Ondria

----------------------------------------------------------------------------------------------