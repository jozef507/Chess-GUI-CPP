/**
 * main.cpp - Automaticky vygenerováno
 *
 * Main - spuštění programu
 *
 * @author Jan Holásek (xholas09)
 */

#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();
}
